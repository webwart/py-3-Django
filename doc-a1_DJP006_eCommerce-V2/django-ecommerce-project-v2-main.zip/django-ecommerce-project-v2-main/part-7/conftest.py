pytest_plugins = [
    "ecommerce.tests.inventory_fixtures",
    "ecommerce.tests.api_client",
]
