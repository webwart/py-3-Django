from django.contrib import admin
from ecommerce.inventory.models import Category

admin.site.register(Category)
