## Dependancies

black==21.9b0
Django==3.2.8
django-mptt==0.13.4
factory-boy==3.2.0
Pillow==8.4.0
psycopg2-binary==2.9.2
pytest-django==4.4.0
pytest-factoryboy==2.1.0
selenium==4.0.0



https://stackoverflow.com/questions/23639113/disable-a-method-in-a-viewset-django-rest-framework