# ix_django

Installationsschritte für Ubuntu

*  In gewünschtes Verzeichnis wechseln
*  git clone URL
*  In ausgechecktes Verzeichnis wechseln
*  VirtualEnv erzeugen: python3.8 -m venv venv
*  VirtualEnv aktivieren: source venv/bin/activate
*  Packages installieren: pip install -r requiremenets/dev.txt
*  Entwicklungsserver starten: python manage.py runserver
*  SQLite Datenbank mit Demodaten bereits enthalten
*  Bereits angelegter Benutzer "root" mit Passwort "root"