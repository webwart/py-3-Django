from django.apps import AppConfig


class AufgabenConfig(AppConfig):
    name = 'Aufgaben'
