from django.apps import AppConfig


class ThetaImageConfig(AppConfig):
    name = 'theta_image'
