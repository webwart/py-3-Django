from django.contrib import admin
from .models import Thetaimage

admin.site.register(Thetaimage)

