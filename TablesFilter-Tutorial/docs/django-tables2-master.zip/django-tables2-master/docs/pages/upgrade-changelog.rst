Upgrading and change log
========================

Recent versions of django-tables2 have a corresponding git tag for each version
released to `pypi <https://pypi.python.org/pypi/django-tables2>`_.


.. toctree::
    :maxdepth: 1

    CHANGELOG.md
