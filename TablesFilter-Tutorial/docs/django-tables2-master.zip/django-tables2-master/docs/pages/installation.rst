Installation
============

Django-tables2 is `Available on pypi <https://pypi.python.org/pypi/django-tables2>`_
and can be installed using pip::

    pip install django-tables2

After installing, add ``'django_tables2'`` to ``INSTALLED_APPS`` and make sure
that ``"django.template.context_processors.request"`` is added to the
``context_processors`` in your template setting ``OPTIONS``.
