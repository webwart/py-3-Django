---
name: Bug report
about: Updating to 2.0? Did you read the migration guide? https://django-filter.readthedocs.io/en/master/guide/migration.html#migration-guide

---


