# from django.test import TestCase

# class TestClass(TestCase):
#     def test_hello_world(self):
#         self.assertEqual("hello", "hello")

# import pytest

# @pytest.mark.slow
# def test_hello_world():
#     assert "hello" == "hello"